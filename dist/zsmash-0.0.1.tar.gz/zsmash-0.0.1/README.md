# zsmash

---

Rapid evaluation of quantified simialrity between streaming data using data smashing and newer implementations